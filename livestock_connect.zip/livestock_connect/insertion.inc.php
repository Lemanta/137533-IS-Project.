<?php 
 
require 'connect.php';

session_start();

//Register User
if (isset($_POST['regu'])) {
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $type = $_POST['type'];
 $mod = $_POST['mod'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];

 if ($password == $passwordconfirm) {
    if($mod == 1){
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Email_Address`,`User_Type`, `Password`) VALUES ('$fname','$phone','$email','$type',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: index.html?userregistration=success");
 }else{
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Email_Address`, `User_Type`, `Password`) VALUES ('$fname','$phone','$email','$type',md5('$password'))";
     mysqli_query($conn, $sql);
  header("Location: admin.php?userregistration=success");
  }
}else{
  echo "Passwords do not match.";
 }
}

//Update User
if (isset($_POST['upu'])) {
 $uid = $_POST['uid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];
 $phone = $_POST['phone'];
 $mod = $_POST['mod'];

 if ($password == $passwordconfirm) {
  if ($mod == 1) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: admin.php?updateadministrator=success");
  }else if ($mod == 2) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: farmer.php?updatefarmer=success");
  }else if ($mod == 3) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: buyer.php?updatebuyer=success");
  }else if ($mod == 4) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: middleman.php?updatemiddleman=success");
  }else if ($mod == 5) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: vet.php?updatevet=success");
  }
 }else{
  echo "Passwords do not match.";
 }
}

//Delete A User
if($_REQUEST['action'] == 'deleteU' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$sql = "DELETE FROM `users` WHERE `User_ID` = '$deleteItem'";
mysqli_query($conn, $sql); 
header("Location: admin.php?deleteuser=success");
}

//Add an Order
if (isset($_POST['orderproduct'])) {
 $bname = $_SESSION['buyername1'];
 $prof = explode(',', $_POST['prof']);
 $pro = $prof[0];
 $fname = $prof[1];
 $price = $prof[2];
 $quan1 = $prof[3];
 $means = "Payment to be made via " . $_POST['means'] . " & to be delivered to " . $_POST['means1']; 
 $quan = $_POST['quan'];
 $pri = $price * $_POST['quan'];

if(($quan1 - $quan) >= 0){

  $sql = "INSERT INTO `market`(`Buyer_Name`, `Farmer_Name`, `Means`, `Product_Name`, `Price`, `Quantity`) VALUES ('$bname','$fname','$means','$pro','$pri','$quan')";
     mysqli_query($conn, $sql);
       $sql1 = "UPDATE `products` SET `Quantity` = `Quantity` - '$quan' WHERE `Name` = '$pro'";
     mysqli_query($conn, $sql1);
  }else{
   echo "Quantity Ordered exceeds the amount in stock, kindly try again.";
  }
  header("Location: buyer.php?orderproduct=success");

 }

//Accept an Order
if($_REQUEST['action'] == 'acceptO' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$mname = $_SESSION['middlemanname1'];
$sql = "UPDATE `market` SET `Middleman_Name` = '$mname', `Status` = 'On Route' WHERE `Market_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: middleman.php?acceptOrder=success");
}

//Complete an Order
if($_REQUEST['action'] == 'completeO' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$sql = "UPDATE `market` SET `Status` = 'Completed' WHERE `Market_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: middleman.php?completedOrder=success");
}

//Cancel an Order
if($_REQUEST['action'] == 'cancelO' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$sql = "UPDATE `market` SET `Status` = 'Cancelled' WHERE `Market_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: buyer.php?cancelOrder=success");
}

//Add a Product
if (isset($_POST['addproduct'])) {
 $fname = $_SESSION['farmname1'];
 $pname = $_POST['pname'];
 $quan = $_POST['quan'];
 $pri = $_POST['pri'];

$filename = $_FILES['file']['name'];

$valid_extensions = array("jpg","jpeg","png");

$extension = pathinfo($filename, PATHINFO_EXTENSION);

if(in_array(strtolower($extension),$valid_extensions) ) {

if(move_uploaded_file($_FILES['file']['tmp_name'], "images/".$filename)){

  $sql = "INSERT INTO `products`(`Name`, `Farmer_Name`, `Quantity`, `Price`, `Image`) VALUES ('$pname','$fname','$quan','$pri','$filename')";
     mysqli_query($conn, $sql);
  header("Location: farmer.php?addproduct=success");
 }else{
  echo "There is an error with the image, directory not found.";
}
}else{
  echo "There is an error with the image, kindly check the image format.";
}
}

//Delete A Product
if($_REQUEST['action'] == 'deleteP' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$sql = "DELETE FROM `products` WHERE `Product_ID` = '$deleteItem'";
mysqli_query($conn, $sql); 
header("Location: farmer.php?deleteproduct=success");
}

//Update a Product
if (isset($_POST['updateproduct'])) {
 $pid = $_POST['pid'];
 $quan = $_POST['quan'];

  $sql = "UPDATE `products` SET `Quantity` = `Quantity` + '$quan' WHERE `Product_ID` = '$pid'";
     mysqli_query($conn, $sql);
  header("Location: farmer.php?updateproductQuantity=success");
}

//Add a Livestock 
if (isset($_POST['addlivestock'])) {
 $fname = $_SESSION['farmname1'];
 $lname = $_POST['lname'];
 $quan = $_POST['quan'];

$filename = $_FILES['file']['name'];

$valid_extensions = array("jpg","jpeg","png");

$extension = pathinfo($filename, PATHINFO_EXTENSION);

if(in_array(strtolower($extension),$valid_extensions) ) {

if(move_uploaded_file($_FILES['file']['tmp_name'], "images/".$filename)){

  $sql = "INSERT INTO `livestock`(`Name`, `Farmer_Name`, `Vet_Name`, `Quantity`, `Image`) VALUES ('$lname','$fname','TBC','$quan','$filename')";
     mysqli_query($conn, $sql);
  header("Location: farmer.php?addlivestock=success");
 }else{
  echo "There is an error with the image, directory not found.";
}
}else{
  echo "There is an error with the image, kindly check the image format.";
}
}

//Delete A Livestock
if($_REQUEST['action'] == 'deleteL' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$sql = "DELETE FROM `livestock` WHERE `Livestock_ID` = '$deleteItem'";
mysqli_query($conn, $sql); 
header("Location: farmer.php?deletelivestock=success");
}

//Request a Vet for Livestock
if (isset($_POST['requestVet'])) {
 $lid = $_POST['lid'];
 $vname = $_POST['vname'];

  $sql = "UPDATE `livestock` SET `Status` = 'The livestock is in need of a check-up by the requested vet.', `Vet_Name` = '$vname' WHERE `Livestock_ID` = '$lid'";
     mysqli_query($conn, $sql);
  header("Location: farmer.php?requestaVet=success");
}

//Update a Livestock Status
if (isset($_POST['updatelivestock'])) {
 $lid = $_POST['type'];
 $stat = $_POST['stat'];

  $sql = "UPDATE `livestock` SET `Status` = '$stat' WHERE `Livestock_ID` = '$lid'";
     mysqli_query($conn, $sql);
  header("Location: vet.php?updateLivestock=success");
}

 ?>