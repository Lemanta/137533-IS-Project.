<?php
require_once "connect.php";

session_start();


if(isset($_POST['login'])){

    $id = $_POST['email'];
    $password = $_POST['password'];   

        $sql = "SELECT * FROM `users` WHERE `Email_Address`='$id'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){
            $row = mysqli_fetch_assoc($query);

            $pass = $row['Password'];
            $type = $row['User_Type'];

if(md5($password) == $pass){

                if ($type == "Administrator") {
                $_SESSION['adminname'] = $row['User_ID'];
                header("Location: admin.php");
                }else if ($type == "Vet") {
                $_SESSION['vetname'] = $row['User_ID'];
                $_SESSION['vetname1'] = $row['Fullname'];                
                header("Location: vet.php");
                }else if ($type == "Middleman") {
                $_SESSION['middlemanname'] = $row['User_ID'];
                $_SESSION['middlemanname1'] = $row['Fullname'];                
                header("Location: middleman.php");
                }else if ($type == "Farmer") {
                $_SESSION['farmname'] = $row['User_ID'];
                $_SESSION['farmname1'] = $row['Fullname'];
                header("Location: farmer.php");
                }else if ($type == "Buyer") {
                $_SESSION['buyername'] = $row['User_ID'];
                $_SESSION['buyername1'] = $row['Fullname'];
                header("Location: buyer.php");
                }
            }else{
                echo "Incorrect Password.";
            }
        }else{
            echo "User does not exist.";
        }
}
           
?>
